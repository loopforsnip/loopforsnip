# Game version 0.9.5
Krunker.io game hack. Aim, NameESP, NoRecoil, Infinity Ammo and etc.

# Installing Chrome/Chromium extension
1. [Download](https://github.com/wallopthecat/Krunker-hack/archive/master.zip) this repo and extract it.
2. Open `chrome://extensions/` in chrome or chromium.
3. Drag and drop the [Krunker-hack](https://github.com/wallopthecat/Krunker-hack) folder from the downloaded repo into opened extension window.

All actions you take at your own risk. The author is not responsible for the consequences of your actions.
